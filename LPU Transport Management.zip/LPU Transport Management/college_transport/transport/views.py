from django.shortcuts import render, redirect
from .models import Student, BusPass, BusRoute
from .forms import StudentForm, BusPassForm

def home(request):
    students = Student.objects.all()
    return render(request, 'transport/home.html', {'students': students})

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = StudentForm()
    bus_routes = BusRoute.objects.all()
    return render(request, 'transport/add_student.html', {'form': form, 'bus_routes': bus_routes})

def issue_bus_pass(request):
    if request.method == 'POST':
        form = BusPassForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BusPassForm()
    students = Student.objects.all()
    return render(request, 'transport/issue_bus_pass.html', {'form': form, 'students': students})

def bus_routes(request):
    routes = BusRoute.objects.all()
    return render(request, 'transport/bus_routes.html', {'routes': routes})
