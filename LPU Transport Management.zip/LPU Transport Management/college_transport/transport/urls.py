from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add_student/', views.add_student, name='add_student'),
    path('issue_bus_pass/', views.issue_bus_pass, name='issue_bus_pass'),
    path('bus_routes/', views.bus_routes, name='bus_routes'),
]
