from django.db import models


class BusRoute(models.Model):
    route_name = models.CharField(max_length=100)
    start_location = models.CharField(max_length=100)
    end_location = models.CharField(max_length=100)

    def __str__(self):
        return self.route_name

class Student(models.Model):
    name = models.CharField(max_length=100)
    roll_number = models.CharField(max_length=20, unique=True)
    email = models.EmailField()
    bus_route = models.ForeignKey(BusRoute, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.name

class BusPass(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    issue_date = models.DateField(auto_now_add=True)
    expiry_date = models.DateField()
    pass_number = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return f"{self.student.name} - {self.pass_number}"

